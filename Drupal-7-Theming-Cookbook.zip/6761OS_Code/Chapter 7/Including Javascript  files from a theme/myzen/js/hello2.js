(function ($) {
  Drupal.behaviors.myzenAlert = {
    attach: function() {
      alert("Hello World!!");
    }
  };
}(jQuery));
