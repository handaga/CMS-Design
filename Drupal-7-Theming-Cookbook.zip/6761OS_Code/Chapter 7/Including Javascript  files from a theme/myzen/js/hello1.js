(function ($) {
  alert("Hello World!!");
}(jQuery));
