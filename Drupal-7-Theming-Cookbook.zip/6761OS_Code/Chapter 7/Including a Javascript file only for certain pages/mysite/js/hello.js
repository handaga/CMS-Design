(function ($) {
  Drupal.behaviors.mysiteHello = {
    attach: function() {
      alert("Hello World!!");
    }
  };
}(jQuery));
